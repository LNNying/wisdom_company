﻿using System;
using System.Collections.Generic;
using Common.PCL.Utility;

namespace DynamicLoadChart.Ajax
{
    public partial class GetChartData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string type = Request["type"];
            string pointCount = Request["count"];
            if (!string.IsNullOrEmpty(type))
            {
                switch (type)
                { 
                    case "getData":
                        GetAjaxData(pointCount);
                        break;
                }
            }
        }

        /// <summary>
        /// 获得数据且用Json格式数据返回
        /// </summary>
        private void GetAjaxData(string pointCount)
        { 
            //为了演示效果 这里采用随机数据来代替 后期可以根据自己情况换成访问数据获取数据
            //考虑到图表的category是字符串数组 这里定义一个string的List
            List<string> categoryList = new List<string>();
            //考虑到图表的series数据为一个对象数组 这里额外定义一个series的类
            List<Series> seriesList = new List<Series>();

            //考虑到Echarts图表需要设置legend内的data数组为series的name集合这里需要定义一个legend数组
            List<string> legendList = new List<string>();

            int _pointCount;
            //如果数据非整型 默认给予10个数据
            if (!int.TryParse(pointCount,out  _pointCount))
            {
                _pointCount = 10;
            }

            //设置legend数组
            legendList.Add("Series 1"); //这里的名称必须和series的每一组series的name保持一致

            //定义一个Series对象
            Series seriesObj = new Series();
            seriesObj.id = 1;
            seriesObj.name = "Series 1";
            seriesObj.type = "line"; //线性图呈现
            seriesObj.data = new List<int>(); //先初始化 不初始化后面直直接data.Add(x)会报错

            //设置数据
            for (int i = 1; i <= _pointCount; i++)
            { 
                //加入category刻度数组
                categoryList.Add(string.Format("刻度{0}", _pointCount));

                //加入数据值series序列数组 这里提供为了效果只提供一组series数据好了                
                seriesObj.data.Add(i); //数据依次递增
            }
            //将sereis对象压入sereis数组列表内
            seriesList.Add(seriesObj);

            //最后调用相关函数将List转换为Json
            //因为我们需要返回category和series、legend多个对象 这里我们自己在new一个新的对象来封装这两个对象
            var newObj = new { 
                                category = categoryList,
                                series = seriesList,
                                legend = legendList
                                };
            //Response返回新对象的json数据
            Response.Write(newObj.ToJson());
            Response.End();
        }
    }

    /// <summary>
    /// 定义一个Series类 设置其每一组sereis的一些基本属性
    /// </summary>
    class Series
    {
        /// <summary>
        /// sereis序列组id
        /// </summary>
        public int id
        {
            get;
            set;
        }

        /// <summary>
        /// series序列组名称
        /// </summary>
        public string name
        {
            get;
            set;
        }

        /// <summary>
        /// series序列组呈现图表类型(line、column、bar等)
        /// </summary>
        public string type
        {
            get;
            set;
        }

        /// <summary>
        /// series序列组的数据为数据类型数组
        /// </summary>
        public List<int> data
        {
            get;
            set;
        }
    }
}